# Experiment 5: Gitflow, Merge Conflicts, and GitHub Actions

## Aim
To implement a Gitflow-style branching workflow, resolve a merge conflict, and automate Java compilation and execution using GitHub Actions on every push and pull request.

## Requirements
- Git
- Java JDK 17 or later
- A GitHub account (for the automated workflow)

## 1. Run the Java program locally
Open a terminal in this folder and run:

```bash
javac Main.java
java Main
```

Expected output:

```text
Experiment 5: Gitflow and GitHub Actions
Java application executed successfully.
```

## 2. Initialize Git and create branches

```bash
git init
git branch -M main
git add .
git commit -m "Initial commit"
git checkout -b develop
git checkout -b feature/experiment-message
```

Make a small change in `Main.java`, then commit it:

```bash
git add Main.java
git commit -m "Add experiment message"
git checkout develop
git merge feature/experiment-message
```

## 3. Demonstrate a merge conflict (practice only)
Create a branch and change the same line in `Main.java` differently on each branch:

```bash
git checkout -b feature/change-message
```

Edit the printed message in `Main.java`, then:

```bash
git add Main.java
git commit -m "Change message in feature branch"
git checkout develop
```

Edit the same line in `Main.java` to a different message, then:

```bash
git add Main.java
git commit -m "Change message in develop"
git merge feature/change-message
```

Git should report a conflict if both branches changed the same line. Open `Main.java`, choose the desired final line, and remove conflict markers (`<<<<<<<`, `=======`, `>>>>>>>`). Then run:

```bash
git add Main.java
git commit -m "Resolve merge conflict"
```

## 4. Push to GitHub
Create an empty repository on GitHub, then use its URL below:

```bash
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
git push -u origin develop
git push -u origin --all
```

Replace the URL with your own repository URL. If GitHub asks you to authenticate, use the sign-in flow or a personal access token; do not put passwords or tokens in this file.

## 5. Verify GitHub Actions
The workflow is stored at `.github/workflows/ci.yml`. After pushing the repository, open the repository's **Actions** tab. The workflow runs on each push and pull request, compiles `Main.java`, and runs the program.

## Workflow summary
`Code change -> Git commit -> Push/Pull Request -> GitHub Actions -> Compile -> Run`

## Result
Git branching and merging are practiced, a merge conflict is resolved, and GitHub Actions automatically compiles and runs the Java program on pushes and pull requests.
