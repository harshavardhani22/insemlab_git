public class Main {
    public static void main(String[] args) {
        System.out.println("Experiment 5: Gitflow and GitHub Actions");
        System.out.println("Java application executed successfully.");
    }
}
